export class Supplier {
  supplierId: number;
  supplierName: string;
  phoneNumber: string;
  email: string;
  address: string;
}
