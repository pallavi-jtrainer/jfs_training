export class Buyer {
  buyerId: number;
  buyerName: string;
  addr: string;
  contact: string;
  emailAddr: string;
  walletBalance: number;
}
