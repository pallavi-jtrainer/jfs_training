import { Items } from './../item-details/items';
import { Supplier } from './../supplier-dash/Supplier';
import { ItemsService } from './../items.service';
import { SupplierService } from './../supplier.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-item',
  templateUrl: './add-item.component.html',
  styleUrls: ['./add-item.component.css']
})
export class AddItemComponent implements OnInit {

  sId: number;
  s: Supplier;
  item: Items;
  name = '';
  unitprice = 0;
  cat = '';

  constructor(private router: Router, private route: ActivatedRoute,
              private supplierService: SupplierService, private itemService: ItemsService) { }

  ngOnInit(): void {
    this.reloadData();
  }

  goHome() {
    this.router.navigate(['/suppdash', this.sId]);
  }

  loadDetails() {
    this.router.navigate(['/suppdetails', this.sId]);
  }

  showMyOrders() {
    this.router.navigate(['/supplierhistory', this.sId]);
  }

  showPendingOrders() {
    this.router.navigate(['/pendingorders', this.sId]);
  }

  reloadData() {
    this.s = new Supplier();

    // tslint:disable-next-line: radix
    this.sId = parseInt(this.route.snapshot.paramMap.get('id'));

    this.supplierService.getSupplierById(this.sId)
      .subscribe(data => {
        console.log(data);
        this.s = data;
      }, error => console.log(error));
  }

  addProduct(id: number) {
    this.item = new Items();

    if (this.name === '' || this.unitprice === 0 || this.cat === '') {
      alert('All fields are required. Please fill all the fields');
      this.reloadData();
    }

    const re = /\ /gi;

    this.name = this.name.replace(re, '_');
    this.item.itemName = this.name;
    this.item.price = this.unitprice;
    this.item.itemCategory = this.cat;
    // console.log(this.cat);
    this.itemService.addNewItem(this.item, id)
      .subscribe(data => {
        console.log(data);
        alert(data);
        this.goHome();
      });
  }
}
