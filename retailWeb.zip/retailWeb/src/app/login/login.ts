export class Login {
  userId: number;
  userName: string;
  password: string;
  userType: string;
}
