export class Items {
  itemId: number;
  itemName: string;
  price: number;
  supplierId: number;
  itemCategory: string;
}
