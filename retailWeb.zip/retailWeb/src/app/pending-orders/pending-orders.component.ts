import { ItemsService } from './../items.service';
import { Items } from './../item-details/items';
import { Orders } from './../order-details/orders';
import { Observable } from 'rxjs';
import { Supplier } from './../supplier-dash/Supplier';
import { SupplierService } from './../supplier.service';
import { OrdersService } from './../orders.service';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-pending-orders',
  templateUrl: './pending-orders.component.html',
  styleUrls: ['./pending-orders.component.css']
})
export class PendingOrdersComponent implements OnInit {

  sId: number;
  s: Supplier;
  orders: Observable<Orders[]>;
  order: Orders;
  amt: number;
  i: Items;
  id: number;
  name: string;
  supName: string;

  constructor(private router: Router, private route: ActivatedRoute,
              private orderService: OrdersService, private supplierService: SupplierService,
              private itemService: ItemsService) { }

  ngOnInit(): void {
    this.reloadData();
  }

  goHome() {
    this.router.navigate(['/suppdash', this.sId]);
  }


  reloadData() {
    // tslint:disable-next-line: radix
    this.sId = parseInt(this.route.snapshot.paramMap.get('id'));

    this.supplierService.getSupplierById(this.sId)
      .subscribe(data => {
        console.log(data);
        this.s = data;
        this.supName = this.s.supplierName;
      }, error => console.log(error));

    this.supplierService.pendingOrdersList(this.sId)
      .subscribe(data1 => {
        console.log(data1);
        this.orders = data1;

        data1.forEach(one => {
          this.id = one.itemId;
          this.orderService.getOrderById(one.orderId)
            .subscribe(x => {
              console.log(x);
              this.order = x;
              this.amt = this.order.orderAmt;
            });

          this.itemService.getItemById(this.id)
          .subscribe(info => {
            console.log(info);
            this.i = info;
            this.name = this.i.itemName;
          });
        });
      });
  }

  acceptOrder(id: number) {
    this.orderService.getOrderById(id)
      .subscribe(data => {
        console.log(data);
        this.order = data;
        this.supplierService.updateStatus(this.order, 'ACCEPTED', this.amt)
          .subscribe(data1 => {
            console.log(data1);
            alert(data1);
          });
      });

    this.reloadData();
  }

  denyOrder(id: number) {
    this.orderService.getOrderById(id)
      .subscribe(data => {
        console.log(data);
        this.order = data;

        this.supplierService.updateStatus(this.order, 'DENIED', this.amt)
          .subscribe(data1 => {
            console.log(data1);
            alert(data1);
         });
      });

    this.reloadData();
  }

  loadDetails() {
    this.router.navigate(['/suppdetails', this.sId]);
  }

  showMyOrders() {
    this.router.navigate(['/supplierhistory', this.sId]);
  }
}
