export class Orders {
  orderId: number;
  orderDate: string;
  buyerId: number;
  supplierId: number;
  itemId: number;
  itemQuantity: number;
  orderAmt: number;
  orderStatus: string;
}
