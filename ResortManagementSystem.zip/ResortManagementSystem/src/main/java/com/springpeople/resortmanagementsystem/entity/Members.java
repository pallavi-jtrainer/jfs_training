package com.springpeople.resortmanagementsystem.entity;

import java.time.LocalDate;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * Members class
 */
@Entity
@Table(name="members")
public class Members {
	@Id
	@Column(name = "memberid")
	private int memberId;
	
	@Column(name = "membername")
	private String memberName;
	
	@Column(name = "email")
	private String email;
	
	@Column(name = "passkey")
	private String passkey;
	
	@Column(name="phone")
	private String phone;
	
	@Column(name = "walletbalance")
	private double walletBalance;
	
	@Column(name="memberstatus")
	private MemberStatus memberStatus;
	
	@Column(name="membershipdate")
	private LocalDate membershipDate;

	public int getMemberId() {
		return memberId;
	}

	public void setMemberId(int memberId) {
		this.memberId = memberId;
	}

	public String getMemberName() {
		return memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPasskey() {
		return passkey;
	}

	public void setPasskey(String passkey) {
		this.passkey = passkey;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public double getWalletBalance() {
		return walletBalance;
	}

	public void setWalletBalance(double walletBalance) {
		this.walletBalance = walletBalance;
	}

	public MemberStatus getMemberStatus() {
		return memberStatus;
	}
	
	public void setMemberStatus(MemberStatus memberStatus) {
		this.memberStatus = memberStatus;
	}

	public LocalDate getMembershipDate() {
		return membershipDate;
	}
	
	public void setMembershipDate(LocalDate membershipDate) {
		this.membershipDate = membershipDate;
	}

	@Override
	public int hashCode() {
		return Objects.hash(email, memberId, memberName, memberStatus, membershipDate, passkey, phone, walletBalance);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Members other = (Members) obj;
		return Objects.equals(email, other.email) && memberId == other.memberId
				&& Objects.equals(memberName, other.memberName) && memberStatus == other.memberStatus
				&& Objects.equals(membershipDate, other.membershipDate) && Objects.equals(passkey, other.passkey)
				&& Objects.equals(phone, other.phone)
				&& Double.doubleToLongBits(walletBalance) == Double.doubleToLongBits(other.walletBalance);
	}
	
	@Override
	public String toString() {
		return "Members [memberId=" + memberId + ", memberName=" + memberName + ", email=" + email + ", passkey="
				+ passkey + ", phone=" + phone + ", walletBalance=" + walletBalance + ", memberStatus=" + memberStatus
				+ ", membershipDate=" + membershipDate + "]";
	}

	public Members(int memberId, String memberName, String email, String passkey, String phone, double walletBalance,
			MemberStatus memberStatus, LocalDate membershipDate) {
		this.memberId = memberId;
		this.memberName = memberName;
		this.email = email;
		this.passkey = passkey;
		this.phone = phone;
		this.walletBalance = walletBalance;
		this.memberStatus = memberStatus;
		this.membershipDate = membershipDate;
	}

	public Members() {
		
	}
	
}
