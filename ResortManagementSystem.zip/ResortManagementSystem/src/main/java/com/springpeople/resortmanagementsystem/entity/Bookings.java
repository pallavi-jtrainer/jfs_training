package com.springpeople.resortmanagementsystem.entity;

import java.time.LocalDate;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="bookings")
public class Bookings {
	@Id
	@Column(name="bookingid")
	private int bookingId;
	
	@Column(name="bookingdate")
	private LocalDate bookingDate;
	
	@Column(name="totalamt")
	private double totalAmount;
	
	@Column(name="numrooms")
	private int numRooms;
	
	@Column(name="no_ofnights")
	private int noOfNights;
	
	@Column(name="fromdate")
	private LocalDate fromDate;
	
	@Column(name="memberid")
	private int memberId;
	
	@Column(name="employeeid")
	private int employeeId;
	
	@Column(name="bookingstatus")
	private BookingStatus bookingStatus;

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public LocalDate getBookingDate() {
		return bookingDate;
	}

	public void setBookingDate(LocalDate bookingDate) {
		this.bookingDate = bookingDate;
	}

	public double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public int getNumRooms() {
		return numRooms;
	}

	public void setNumRooms(int numRooms) {
		this.numRooms = numRooms;
	}

	public int getMemberId() {
		return memberId;
	}

	public void setMemberId(int memberId) {
		this.memberId = memberId;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	
	public BookingStatus getBookingStatus() {
		return bookingStatus;
	}
	
	public void setBookingStatus(BookingStatus bookingStatus) {
		this.bookingStatus = bookingStatus;
	}

	public Bookings() {
		
	}

	public Bookings(int bookingId, LocalDate bookingDate, double totalAmount, int numRooms, int noOfNights,
			LocalDate fromDate, int memberId, int employeeId, BookingStatus bookingStatus) {
		this.bookingId = bookingId;
		this.bookingDate = bookingDate;
		this.totalAmount = totalAmount;
		this.numRooms = numRooms;
		this.noOfNights = noOfNights;
		this.fromDate = fromDate;
		this.memberId = memberId;
		this.employeeId = employeeId;
		this.bookingStatus = bookingStatus;
	}

	@Override
	public int hashCode() {
		return Objects.hash(bookingDate, bookingId, bookingStatus, employeeId, fromDate, memberId, noOfNights, numRooms,
				totalAmount);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Bookings other = (Bookings) obj;
		return Objects.equals(bookingDate, other.bookingDate) && bookingId == other.bookingId
				&& bookingStatus == other.bookingStatus && employeeId == other.employeeId
				&& Objects.equals(fromDate, other.fromDate) && memberId == other.memberId
				&& noOfNights == other.noOfNights && numRooms == other.numRooms
				&& Double.doubleToLongBits(totalAmount) == Double.doubleToLongBits(other.totalAmount);
	}

	@Override
	public String toString() {
		return "Bookings [bookingId=" + bookingId + ", bookingDate=" + bookingDate + ", totalAmount=" + totalAmount
				+ ", numRooms=" + numRooms + ", noOfNights=" + noOfNights + ", fromDate=" + fromDate + ", memberId="
				+ memberId + ", employeeId=" + employeeId + ", bookingStatus=" + bookingStatus + "]";
	}
	
	
}
