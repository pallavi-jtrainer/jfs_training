package com.springpeople.resortmanagementsystem.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springpeople.resortmanagementsystem.entity.Facilities;
import com.springpeople.resortmanagementsystem.exceptions.ResourceNotFoundException;
import com.springpeople.resortmanagementsystem.repository.FacilitiesRepository;

@Service
public class FacilitiesService {

	@Autowired
	private FacilitiesRepository repo;
	
	public List<Facilities> listAllFacilities() {
		return repo.findAll();
	}
	
	public List<Facilities> listAllByPrice(double min, double max) {
		return repo.findAllByPriceBetween(min, max);
	}
	
	public Facilities retrieveFacilityDetails(int id) throws ResourceNotFoundException {
		Facilities f = repo.findByFacilityId(id);
		
		if(f == null) {
			throw new ResourceNotFoundException("Facility with id: " + id + " not found");
		}
		
		return f;
	}
	
	public Facilities retrieveFacilityDetailsByName(String name) throws ResourceNotFoundException {
		Facilities f = repo.findByFacilityName(name);
		
		if(f == null) {
			throw new ResourceNotFoundException("Facility with name: " + name + " not found");
		}
		
		return f;
	}
	
	public Facilities createNewFacility(Facilities facility) {
		Facilities f = repo.findFirstByOrderByFacilityIdDesc();
		
		int id = 5001;
		
		if (f != null) {
			id = f.getFacilityId() + 1;
		}
		
		facility.setFacilityId(id);
		
		return repo.save(facility);
	}
	
	public String updateFacilityPrice(int id, double price) throws ResourceNotFoundException {
		String str = "Unable to update price";
		
		Facilities f = repo.findByFacilityId(id);
		
		if(f == null) {
			throw new ResourceNotFoundException("Facility with id: " + id + " not found");
		}
		
		int res = repo.updatePrice(id, price);
		if(res > 0) {
			str = "Price for facility with id: " + id + " updated successfully";
		}
		
		return str;
	}
	
	public String addToFacilitiesAvailed(int id, int mem, LocalDate date) {
		String str = "Unable to add to Availed facilities";
		
		int res = repo.insertIntoAvailed(id, mem, date);
		if(res > 0) {
			str = "Uploaded the facilties availed data for member with id: " + mem; 
		}
		
		return str;
	}
	
	public List<Object> listAllAvailedFacilitiesByMember(int id) {
		return repo.listByMemberId(id);
	}
}
