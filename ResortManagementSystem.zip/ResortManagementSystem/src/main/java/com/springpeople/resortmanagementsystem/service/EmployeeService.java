package com.springpeople.resortmanagementsystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springpeople.resortmanagementsystem.entity.Employees;
import com.springpeople.resortmanagementsystem.exceptions.ResourceNotFoundException;
import com.springpeople.resortmanagementsystem.repository.EmployeeRepository;

@Service
public class EmployeeService {

	@Autowired
	private EmployeeRepository repo;
	
	public List<Employees> listAllEmployees() {
		return repo.findAll();
	}
	
	public Employees retrieveDetailsById(int id) throws ResourceNotFoundException{
		Employees e = repo.findByEmployeeId(id);
		
		if(e == null) {
			throw new ResourceNotFoundException("Employee with id: " + id + " does not exist");
		}
		
		return e;
	}
	
	public Employees retrieveDetailsByEmail(String email) throws ResourceNotFoundException{
		Employees e = repo.findByEmail(email);
		
		if(e == null) {
			throw new ResourceNotFoundException("Employee with email: " + email + " does not exist");
		}
		
		return e;
	}
	
	public Employees createEmployee(Employees employee) {
		Employees e = repo.findFirstByOrderByEmployeeIdDesc();
		int id = 1001;
		
		if(e != null) {
			id = e.getEmployeeId() + 1;
		}
		
		employee.setEmployeeId(id);
		
		return repo.save(employee);
	}
	
	public String updatePassword(int id, String pass) {
		String str = "Unable to update password. Try again later";
		
		int res = repo.updatePassword(id, pass);
		if(res > 0) {
			str = "Password updated successfully";
		}
		
		return str;
	}
	
	public String updatePhone(int id, String phone) {
		String str = "Unable to update phone number. Try again later";
		
		int res = repo.updatePhone(id, phone);
		if(res > 0) {
			str = "Phone number updated successfully";
		}
		
		return str;
	}
	
}
