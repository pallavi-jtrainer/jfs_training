package com.springpeople.resortmanagementsystem.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.springpeople.resortmanagementsystem.entity.Facilities;

@Repository
public interface FacilitiesRepository extends JpaRepository<Facilities, Integer>{
	public Facilities findFirstByOrderByFacilityIdDesc();
	public List<Facilities> findAllByPriceBetween(double min, double max);
	public Facilities findByFacilityName(String name);
	public Facilities findByFacilityId(int id);
	
	@Modifying
	@Query("update Facilities f set f.price = :price where f.facilityId = :id")
	public int updatePrice(@Param("id") int id, @Param("price") double price);
	
	@Modifying
	@Query(value="INSERT INTO AVAILED (FACILITYID, MEMBERID, AVAILEDDATE) VALUES (:id, :mem, :date)", nativeQuery = true)
	public int insertIntoAvailed(@Param("id") int id, @Param("mem") int mem, @Param("date") LocalDate date);

	@Query(value="SELECT FACILITYID, MEMBERID, AVAILEDDATE FROM AVAILED WHERE MEMBERID = :id", 
			nativeQuery = true)
	public List<Object> listByMemberId(int id);
}
