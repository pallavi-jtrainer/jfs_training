package com.springpeople.resortmanagementsystem.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.springpeople.resortmanagementsystem.entity.MemberStatus;
import com.springpeople.resortmanagementsystem.entity.Members;

@Repository
public interface MemberRepository extends JpaRepository<Members, Integer>{
	public Members findFirstByOrderByMemberIdDesc();
	public Members findByMemberId(int id);
	public Members findByEmail(String email);
	
	@Modifying
	@Query("update Members m set m.passkey = :pass where m.memberId = :id")
	public int updatePassword(@Param("id") int id, @Param("pass") String pass);
	
	@Modifying
	@Query("update Members m set m.phone = :phone where m.memberId = :id")
	public int updatePhone(@Param("id") int id, @Param("phone") String phone);
	
	@Modifying
	@Query("update Members m set m.walletBalance = :bal where m.memberId = :id")
	public int updateWalletBalance(@Param("id") int id, @Param("bal") double bal);
	
	@Modifying
	@Query("update Members m set m.memberStatus = :status where m.memberId = :id")
	public int updateStatus(@Param("id") int id, @Param("status") MemberStatus status);
	
	public List<Members> findAllByMemberStatus(int status);
}
