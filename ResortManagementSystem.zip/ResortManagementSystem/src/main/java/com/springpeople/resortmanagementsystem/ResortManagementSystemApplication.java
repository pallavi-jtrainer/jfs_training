package com.springpeople.resortmanagementsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResortManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResortManagementSystemApplication.class, args);
	}

}
