package com.springpeople.resortmanagementsystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springpeople.resortmanagementsystem.entity.Members;
import com.springpeople.resortmanagementsystem.exceptions.ResourceNotFoundException;
import com.springpeople.resortmanagementsystem.service.MemberService;

import jakarta.transaction.Transactional;

@CrossOrigin("http://localhost:4200")
@RestController
@RequestMapping("/api/members")
public class MemberController {

	@Autowired
	private MemberService service;
	
	//------------------------ Get Mappings -----------------
	
	@GetMapping
	public ResponseEntity<List<Members>> listAllMembers() {
		List<Members> list = service.listAllMembers();
		return ResponseEntity.ok().body(list);
	}
	
	@GetMapping("/{id}")
	public Members getMemberDetailsById(@PathVariable int id) throws ResourceNotFoundException {
		return service.retrieveDetailsById(id);
	}
	
	@GetMapping("/em/{email}")
	public Members getMemberDetailsByEmail(@PathVariable String email) throws ResourceNotFoundException {
		return service.retrieveDetailsByEmail(email);
	}
	
	@GetMapping("/status/{stat}")
	public ResponseEntity<List<Members>> listAllMembersByStatus(@PathVariable int stat) {
		List<Members> list = service.listAllMembersByStatus(stat);
		return ResponseEntity.ok().body(list);
	}
	
	//---------------------Post Mappings -----------------------------
	
	@PostMapping
	public Members createNewMember(@RequestBody Members member) {
		return service.createMember(member);
	}
	
	// ------------------------ Put Mappings ------------------------
	
	@Transactional
	@PutMapping("/pass/{id}/{pass}")
	public ResponseEntity<String> updatePassword(@PathVariable int id, @PathVariable String pass) {
		String str = service.updatePassword(id, pass);
		return ResponseEntity.ok().body(str);
	}
	
	@Transactional
	@PutMapping("/phone/{id}/{phone}")
	public ResponseEntity<String> updatePhone(@PathVariable int id, @PathVariable String phone) {
		String str = service.updatePhone(id, phone);
		return ResponseEntity.ok().body(str);
	}
	
	@Transactional
	@PutMapping("/wallet/{id}/{bal}")
	public ResponseEntity<String> updateBalance(@PathVariable int id, @PathVariable double bal) {
		String str = service.updateWalletBalance(id, bal);
		return ResponseEntity.ok().body(str);
	}
	
	@Transactional
	@PutMapping("/stat/{id}/{status}")
	public ResponseEntity<String> updateStatus(@PathVariable int id, @PathVariable String status) {
		String str = service.updateStatus(id, status);
		return ResponseEntity.ok().body(str);
	}
}
