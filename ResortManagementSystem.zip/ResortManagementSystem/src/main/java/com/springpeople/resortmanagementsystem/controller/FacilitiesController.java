package com.springpeople.resortmanagementsystem.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springpeople.resortmanagementsystem.entity.Facilities;
import com.springpeople.resortmanagementsystem.exceptions.ResourceNotFoundException;
import com.springpeople.resortmanagementsystem.service.FacilitiesService;

import jakarta.transaction.Transactional;

@CrossOrigin("http://localhost:4200")
@RestController
@RequestMapping("/api/facilities")
public class FacilitiesController {
	
	@Autowired
	private FacilitiesService service;
	
	@GetMapping
	public ResponseEntity<List<Facilities>> listAll() {
		List<Facilities> list = service.listAllFacilities();
		return ResponseEntity.ok().body(list);
	}
	
	@GetMapping("/price/{min}/{max}")
	public ResponseEntity<List<Facilities>> listAllByPrice(@PathVariable double min, @PathVariable double max) {
		List<Facilities> list = service.listAllByPrice(min, max);
		return ResponseEntity.ok().body(list);
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<Facilities> getFacilityDetails(@PathVariable int id) throws ResourceNotFoundException {
		Facilities f = service.retrieveFacilityDetails(id);
		return ResponseEntity.ok().body(f);
	}
	
	@GetMapping("/name/{name}")
	public ResponseEntity<Facilities> getFacilityDetailsByName(@PathVariable String name) throws ResourceNotFoundException {
		Facilities f = service.retrieveFacilityDetailsByName(name);
		return ResponseEntity.ok().body(f);
	}
	
	@GetMapping("/member/{id}")
	public ResponseEntity<List<Object>> listAllAvailedFacilitiesByMember(@PathVariable int id) {
		List<Object> list = service.listAllAvailedFacilitiesByMember(id);
		return ResponseEntity.ok().body(list);
	}
	
	@PostMapping
	public ResponseEntity<Facilities> createNewFacility(Facilities facility) {
		Facilities f = service.createNewFacility(facility);
		return ResponseEntity.ok().body(f);
	}
	
	@Transactional
	@PostMapping("/add/{id}/{mem}/{date}")
	public ResponseEntity<String> addToFacilitiesAvailed(@PathVariable int id,
			@PathVariable int mem, @PathVariable LocalDate date) {
		String str = service.addToFacilitiesAvailed(id, mem, date);
		return ResponseEntity.ok().body(str);
	}
	
	@Transactional
	@PutMapping("/update/{id}/{price}")
	public ResponseEntity<String> updateFacilityPrice(@PathVariable int id, @PathVariable double price) 
			throws ResourceNotFoundException {
		String str = service.updateFacilityPrice(id, price);
		return ResponseEntity.ok().body(str);
	}
	
	
}
