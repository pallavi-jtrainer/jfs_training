package com.springpeople.resortmanagementsystem.entity;

import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="facilities")
public class Facilities {

	@Id
	@Column(name="facilityid")
	private int facilityId;
	
	@Column(name="facilityname")
	private String facilityName;
	
	@Column(name="price")
	private double price;
	
	public Facilities() {
		
	}
	
	public Facilities(int facilityId, String facilityName, double price) {
		this.facilityId = facilityId;
		this.facilityName = facilityName;
		this.price = price;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public String getFacilityName() {
		return facilityName;
	}

	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	@Override
	public int hashCode() {
		return Objects.hash(facilityId, facilityName, price);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Facilities other = (Facilities) obj;
		return facilityId == other.facilityId && Objects.equals(facilityName, other.facilityName)
				&& Double.doubleToLongBits(price) == Double.doubleToLongBits(other.price);
	}

	@Override
	public String toString() {
		return "Facilities [facilityId=" + facilityId + ", facilityName=" + facilityName + ", price=" + price + "]";
	}	
	
}
