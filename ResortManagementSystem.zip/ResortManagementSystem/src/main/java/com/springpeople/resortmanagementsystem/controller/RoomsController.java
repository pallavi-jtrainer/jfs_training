package com.springpeople.resortmanagementsystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springpeople.resortmanagementsystem.entity.Rooms;
import com.springpeople.resortmanagementsystem.exceptions.ResourceNotFoundException;
import com.springpeople.resortmanagementsystem.service.RoomsService;

import jakarta.transaction.Transactional;

@CrossOrigin("http://localhost:4200")
@RestController
@RequestMapping("/api/rooms")
public class RoomsController {
	
	@Autowired
	private RoomsService service;
	
	@GetMapping
	public ResponseEntity<List<Rooms>> listAll() {
		List<Rooms> list = service.listAllRooms();
		return ResponseEntity.ok().body(list);
	}
	
	@GetMapping("/type/{cat}")
	public ResponseEntity<List<Rooms>> listAllCategoryWise(@PathVariable String cat) {
		List<Rooms> list = service.listAllByCategory(cat);
		return ResponseEntity.ok().body(list);
	}
	
	@GetMapping("/price/{min}/{max}")
	public ResponseEntity<List<Rooms>> listAllByPrice(@PathVariable double min, @PathVariable double max) {
		List<Rooms> list = service.listAllByPrice(min, max);
		return ResponseEntity.ok().body(list);
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<Rooms> retrieveRoomDetails(@PathVariable int id) throws ResourceNotFoundException {
		Rooms r = service.getRoomDetails(id);
		return ResponseEntity.ok().body(r);
	}
	
	@PostMapping
	public ResponseEntity<Rooms> uploadNewRoomDetails(@RequestBody Rooms room) {
		Rooms r = service.uploadNewRoomDetails(room);
		return ResponseEntity.ok().body(r);
	}
	
	@Transactional
	@PutMapping("/avail/{id}/{avail}")
	public ResponseEntity<String> updateRoomAvailability(@PathVariable int id, @PathVariable boolean avail) {
		String str = service.updateRoomAvailability(id, avail);
		return ResponseEntity.ok().body(str);
	}
	
	@Transactional
	@PutMapping("/update/{id}/{avail}")
	public ResponseEntity<String> updateRoomPrice(@PathVariable int id, @PathVariable double price) {
		String str = service.updateRoomPrice(id, price);
		return ResponseEntity.ok().body(str);
	}
}
