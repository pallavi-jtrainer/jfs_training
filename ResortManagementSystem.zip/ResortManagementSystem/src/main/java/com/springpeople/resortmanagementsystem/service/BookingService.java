package com.springpeople.resortmanagementsystem.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springpeople.resortmanagementsystem.entity.BookingStatus;
import com.springpeople.resortmanagementsystem.entity.Bookings;
import com.springpeople.resortmanagementsystem.exceptions.ResourceNotFoundException;
import com.springpeople.resortmanagementsystem.repository.BookingsRepository;

@Service
public class BookingService {
	
	@Autowired
	private BookingsRepository repo;
	
	public List<Bookings> listAll() {
		return repo.findAll();
	}
	
	public List<Bookings> listAllByEmployeeId(int id) {
		return repo.findAllByEmployeeId(id);
	}
	
	public List<Bookings> listAllByMemberId(int id) {
		return repo.findAllByMemberId(id);
	}
	
	public List<Bookings> listAllByBookingDate(LocalDate date) {
		return repo.findAllByBookingDate(date);
	}
	
	public Bookings getBookingDetails(int id) throws ResourceNotFoundException {
		Bookings b = repo.findByBookingId(id);
		
		if(b == null) {
			throw new ResourceNotFoundException("Booking with id: " + id + " not found");
		}
		
		return b;
	}
	
	public Bookings createNewBooking(Bookings booking) {
		Bookings b = repo.findFirstByOrderByBookingIdDesc();
		
		int id = 4001;
		
		if(b != null) {
			id = b.getBookingId() + 1;
		}
		
		booking.setBookingId(id);
		
		return repo.save(booking);
	}
	
	public List<Bookings> listAllPendingBookings() {
		return repo.listPendingBookings();
	}
	
	public List<Bookings> listBookingsForMember(int id, LocalDate date) {
		return repo.findAllByMemberIdAndBookingDate(id, date);
	}
	
	public String updateBookingStatus(int id, String status) {
		String str = "Unable to update status. Try again later";
		
		BookingStatus index = BookingStatus.valueOf(status);
		
		int res = repo.updateBookingStatus(id, index);
		
		if (res > 0) {
			str = "Booking Status updated";
		}
		
		return str;
	}
	
	public String addBookedRoomDetails(int id, int room) {
	String str = "Unable to add the room details to booked rooms.";
	
	int res = repo.insertIntoRoomsBooked(id, room);
	
	if(res > 0) {
		str = "Rooms booked and details uploaded";
	}
	
	return str;
}
	
}
