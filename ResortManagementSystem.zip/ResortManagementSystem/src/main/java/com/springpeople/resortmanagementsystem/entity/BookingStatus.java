package com.springpeople.resortmanagementsystem.entity;

/**
 * BookingStatus Enum
 * @author Pallavi Prasad
 */
public enum BookingStatus {
	PENDING, ACCEPTED, CANCELLED, DENIED
}
