package com.springpeople.resortmanagementsystem.entity;

import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="rooms")
public class Rooms {
	@Id
	@Column(name="roomid")
	private int roomId;
	
	@Column(name="roomtype")
	private String roomType;
	
	@Column(name="price")
	private double price;
	
	@Column(name="available")
	private boolean available;
	
	public int getRoomId() {
		return roomId;
	}
	
	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}
	
	public String getRoomType() {
		return roomType;
	}
	
	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}
	
	public double getPrice() {
		return price;
	}
	
	public void setPrice(double price) {
		this.price = price;
	}
	
	public boolean isAvailable() {
		return available;
	}
	
	public void setAvailable(boolean available) {
		this.available = available;
	}

	@Override
	public int hashCode() {
		return Objects.hash(available, price, roomId, roomType);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Rooms other = (Rooms) obj;
		return available == other.available && Double.doubleToLongBits(price) == Double.doubleToLongBits(other.price)
				&& roomId == other.roomId && Objects.equals(roomType, other.roomType);
	}

	@Override
	public String toString() {
		return "Rooms [roomId=" + roomId + ", roomType=" + roomType + ", price=" + price + ", available=" + available
				+ "]";
	}

	public Rooms(int roomId, String roomType, double price, boolean available) {
		this.roomId = roomId;
		this.roomType = roomType;
		this.price = price;
		this.available = available;
	}
	
	public Rooms() {}
}
