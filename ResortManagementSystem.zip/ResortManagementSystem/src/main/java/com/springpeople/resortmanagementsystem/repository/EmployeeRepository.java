package com.springpeople.resortmanagementsystem.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.springpeople.resortmanagementsystem.entity.Employees;

@Repository
public interface EmployeeRepository extends JpaRepository<Employees, Integer>{
	public Employees findFirstByOrderByEmployeeIdDesc();
	public Employees findByEmployeeId(int id);
	public Employees findByEmail(String email);
	
	@Modifying
	@Query("update Employees e set e.passKey = :pass where e.employeeId = :id")
	public int updatePassword(@Param("id") int id, @Param("pass") String pass);
	
	@Modifying
	@Query("update Employees e set e.phone = :phone where e.employeeId = :id")
	public int updatePhone(@Param("id") int id, @Param("phone") String phone);
}
