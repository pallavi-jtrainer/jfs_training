package com.springpeople.resortmanagementsystem.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.springpeople.resortmanagementsystem.entity.BookingStatus;
import com.springpeople.resortmanagementsystem.entity.Bookings;

@Repository
public interface BookingsRepository extends JpaRepository<Bookings, Integer>{
	public Bookings findFirstByOrderByBookingIdDesc();
	public List<Bookings> findAllByEmployeeId(int id);
	public List<Bookings> findAllByMemberId(int id);
	public Bookings findByBookingId(int id);
	public List<Bookings> findAllByBookingDate(LocalDate date);
	
	@Query(value="Select * from Bookings where bookingstatus = 'PENDING' and bookingdate >= CURRENT_DATE()", nativeQuery = true)
	public List<Bookings> listPendingBookings();
	
	@Modifying
	@Query("update Bookings b set b.bookingStatus = :status where b.bookingId = :id")
	public int updateBookingStatus(@Param("id") int id, @Param("status") BookingStatus status);
	
	public List<Bookings> findAllByMemberIdAndBookingDate(int id, LocalDate date);
	
	public List<Bookings> findAllByFromDate(LocalDate date);
	
	@Modifying
	@Query(value="INSERT INTO ROOMSBOOKED (BOOKINGID, ROOMID) VALUES (:book, :room)", nativeQuery = true)
	public int insertIntoRoomsBooked(@Param("book") int book, @Param("room") int room);
}
