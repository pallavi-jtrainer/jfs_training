package com.springpeople.resortmanagementsystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springpeople.resortmanagementsystem.entity.Employees;
import com.springpeople.resortmanagementsystem.exceptions.ResourceNotFoundException;
import com.springpeople.resortmanagementsystem.service.EmployeeService;

import jakarta.transaction.Transactional;

@CrossOrigin("http://localhost:4200")
@RestController
@RequestMapping("/api/employees")
public class EmployeeController {
	
	@Autowired
	private EmployeeService service;
	
	@GetMapping
	public List<Employees> listAllEmployees() {
		return service.listAllEmployees();
	}
	
	@GetMapping("/{id}")
	public Employees getDetailsById(@PathVariable int id) throws ResourceNotFoundException {
		return service.retrieveDetailsById(id);
	}
	
	@GetMapping("/em/{email}")
	public Employees getDetailsByEmail(@PathVariable String email) throws ResourceNotFoundException {
		return service.retrieveDetailsByEmail(email);
	}
	
	@PostMapping
	public Employees createEmployee(@RequestBody Employees employee) {
		return service.createEmployee(employee);
	}
	
	@Transactional
	@PutMapping("/pass/{id}/{pass}")
	public ResponseEntity<String> updatePassword(@PathVariable int id, @PathVariable String pass) {
		String str = service.updatePassword(id, pass);
		return ResponseEntity.ok().body(str);
	}
	
	@Transactional
	@PutMapping("/phone/{id}/{phone}")
	public ResponseEntity<String> updatePhone(@PathVariable int id, @PathVariable String phone) {
		String str = service.updatePhone(id, phone);
		return ResponseEntity.ok().body(str);
	}
}
