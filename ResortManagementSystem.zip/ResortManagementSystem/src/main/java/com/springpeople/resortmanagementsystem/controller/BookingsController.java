package com.springpeople.resortmanagementsystem.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springpeople.resortmanagementsystem.entity.Bookings;
import com.springpeople.resortmanagementsystem.exceptions.ResourceNotFoundException;
import com.springpeople.resortmanagementsystem.service.BookingService;

import jakarta.transaction.Transactional;

@CrossOrigin("http://localhost:4200")
@RestController
@RequestMapping("/api/bookings")
public class BookingsController {
	
	@Autowired
	private BookingService service;
	
	@GetMapping
	public ResponseEntity<List<Bookings>> listAllBookings() {
		List<Bookings> list = service.listAll();
		return ResponseEntity.ok().body(list);
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<Bookings> getBookingDetails(@PathVariable int id) throws ResourceNotFoundException {
		Bookings b = service.getBookingDetails(id);
		return ResponseEntity.ok().body(b);
	}
	
	@GetMapping("/emp/{id}")
	public ResponseEntity<List<Bookings>> listAllByEmployeeId(@PathVariable int id) {
		List<Bookings> list = service.listAllByEmployeeId(id);
		return ResponseEntity.ok().body(list);
	}
	
	@GetMapping("/mem/{id}")
	public ResponseEntity<List<Bookings>> listAllByMemberId(@PathVariable int id) {
		List<Bookings> list = service.listAllByMemberId(id);
		return ResponseEntity.ok().body(list);
	}
	
	@GetMapping("/date/{date}")
	public ResponseEntity<List<Bookings>> listAllByBookingDate(@PathVariable LocalDate date) {
		List<Bookings> list = service.listAllByBookingDate(date);
		return ResponseEntity.ok().body(list);
	}
	
	@GetMapping("/pending")
	public ResponseEntity<List<Bookings>> listAllPendingBookings() {
		List<Bookings> list = service.listAllPendingBookings();
		return ResponseEntity.ok().body(list);
	}
	
	@GetMapping("/mlist/{id}/{date}")
	public ResponseEntity<List<Bookings>> listBookingsForMember(@PathVariable int id, @PathVariable LocalDate date) {
		List<Bookings> list = service.listBookingsForMember(id, date);
		return ResponseEntity.ok().body(list);
	}
	
	@PostMapping
	public ResponseEntity<Bookings> createNewBooking(@RequestBody Bookings booking) {
		Bookings b = service.createNewBooking(booking);
		return ResponseEntity.ok().body(b);
	}
	
	@Transactional
	@PostMapping("/add/{id}/{room}")
	public ResponseEntity<String> addBookedRoomDetails(@PathVariable int id, @PathVariable int room) {
		String str = service.addBookedRoomDetails(id, room);
		return ResponseEntity.ok().body(str);
	}
	
	
	@Transactional
	@PutMapping("/status/{id}/{stat}")
	public ResponseEntity<String> updateBookingStatus(@PathVariable int id, @PathVariable String stat) {
		String str = service.updateBookingStatus(id, stat);
		return ResponseEntity.ok().body(str);
	}
	
	

}
