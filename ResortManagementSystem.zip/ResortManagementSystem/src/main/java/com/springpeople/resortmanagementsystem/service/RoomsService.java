package com.springpeople.resortmanagementsystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springpeople.resortmanagementsystem.entity.Rooms;
import com.springpeople.resortmanagementsystem.exceptions.ResourceNotFoundException;
import com.springpeople.resortmanagementsystem.repository.RoomsRepository;

@Service
public class RoomsService {
	
	@Autowired
	private RoomsRepository repo;
	
	public List<Rooms> listAllRooms() {
		return repo.findAll();
	}
	
	public List<Rooms> listAllByCategory(String cat) {
		return repo.findAllByRoomType(cat);
	}
	
	public List<Rooms> listAllByPrice(double min, double max) {
		return repo.findAllByPriceBetween(min, max);
	}
	
	public Rooms getRoomDetails(int id) throws ResourceNotFoundException {
		Rooms room = repo.findByRoomId(id);
		
		if(room == null) {
			throw new ResourceNotFoundException("Room with id: " + id + " not found");
		}
		
		return room;
	}
	
	public Rooms uploadNewRoomDetails(Rooms room) {
		Rooms r = repo.findFirstByOrderByRoomIdDesc();
		
		int id = 3001;
		
		if(r != null) {
			id = r.getRoomId() + 1;
		}
		
		room.setRoomId(id);
		
		return repo.save(room);
	}
	
	public String updateRoomAvailability(int id, boolean avail) {
		String str = "Unable to update availability";
		
		int res = repo.updateRoomAvailability(id, avail);
		
		if(res > 0) {
			str = "Room availability updated";
		}
		
		return str;
		
	}
	
	public String updateRoomPrice(int id, double price) {
		String str = "Unable to update price";
		
		int res = repo.updateRoomPrice(id, price);
		
		if(res > 0) {
			str = "Room price updated";
		}
		
		return str;
		
	}
}
