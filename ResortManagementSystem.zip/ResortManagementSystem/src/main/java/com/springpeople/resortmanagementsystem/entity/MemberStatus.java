package com.springpeople.resortmanagementsystem.entity;

public enum MemberStatus {
	ACTIVE, INACTIVE
}
