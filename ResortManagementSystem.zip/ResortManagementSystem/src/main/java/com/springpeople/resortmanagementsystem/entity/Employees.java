package com.springpeople.resortmanagementsystem.entity;

import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * Employee class
 * @author Pallavi Prasad
 */
@Entity
@Table(name="employees")
public class Employees {
	@Id
	@Column(name="employeeid")
	private int employeeId;
	
	@Column(name="employeename")
	private String employeeName;
	
	@Column(name="phone")
	private String phone;
	
	@Column(name="email")
	private String email;
	
	@Column(name="passkey")
	private String passKey;

	/**
	 *
	 * @return employeeId.
	 */
	public int getEmployeeId() {
		return employeeId;
	}

	/**
	 *
	 * @param argEmployeeId for employeeId.
	 */
	public void setEmployeeId(final int argEmployeeId) {
		this.employeeId = argEmployeeId;
	}

	/**
	 *
	 * @return employeeName.
	 */
	public String getEmployeeName() {
		return employeeName;
	}

	/**
	 *
	 * @param argEmployeeName for employeeName.
	 */
	public void setEmployeeName(final String argEmployeeName) {
		this.employeeName = argEmployeeName;
	}

	/**
	 *
	 * @return phone.
	 */
	public String getPhone() {
		return phone;
	}

	/**
	 *
	 * @param argPhone for phone.
	 */
	public void setPhone(final String argPhone) {
		this.phone = argPhone;
	}

	/**
	 *
	 * @return email.
	 */
	public String getEmail() {
		return email;
	}

	/**
	 *
	 * @param argEmail for email.
	 */
	public void setEmail(final String argEmail) {
		this.email = argEmail;
	}

	/**
	 *
	 * @return passKey.
	 */
	public String getPassKey() {
		return passKey;
	}

	/**
	 *
	 * @param argPassKey for passKey.
	 */
	public void setPassKey(final String argPassKey) {
		this.passKey = argPassKey;
	}

	/**
	 * default constructor.
	 */
	public Employees() {

	}

	/**
	 * parameterized constructor.
	 * @param argEmployeeId   for employeeId
	 * @param argEmployeeName for employeeName
	 * @param argPhone        for phone
	 * @param argEmail        for email
	 * @param argPassKey      for passkey
	 */
	public Employees(final int argEmployeeId, final String argEmployeeName, final String argPhone, final String argEmail,
			final String argPassKey) {
		this.employeeId = argEmployeeId;
		this.employeeName = argEmployeeName;
		this.phone = argPhone;
		this.email = argEmail;
		this.passKey = argPassKey;
	}

	/**
	 * hashcode method.
	 * @return int
	 */
	@Override
	public final int hashCode() {
		return Objects.hash(employeeId, employeeName, phone, email, passKey);
	}

	/**
	 * equals method.
	 * @param obj Object
	 * @return boolean
	 */
	@Override
	public final boolean equals(final Object obj) {
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}

		Employees emp = (Employees) obj;
		if (Objects.equals(employeeId, emp.employeeId) && Objects.equals(employeeName, emp.employeeName)
				&& Objects.equals(phone, emp.phone) && Objects.equals(email, emp.email)
				&& Objects.equals(passKey, emp.passKey)) {
			return true;
		}
		return false;
	}

	/**
	 * toString method.
	 * @return string
	 */
	@Override
	public final String toString() {
		return "Employee Details: [Id: " + this.employeeId + " Name: " + this.employeeName + " Phone: " + this.phone
				+ " Email: " + this.email + "]";
	}
}
