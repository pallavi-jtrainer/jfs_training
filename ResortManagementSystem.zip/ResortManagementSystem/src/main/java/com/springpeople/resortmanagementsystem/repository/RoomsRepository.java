package com.springpeople.resortmanagementsystem.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.springpeople.resortmanagementsystem.entity.Rooms;

import jakarta.transaction.Transactional;

public interface RoomsRepository extends JpaRepository<Rooms, Integer>{
	public List<Rooms> findAllByRoomType(String type);
	public List<Rooms> findAllByPriceBetween(double min, double max);
	public Rooms findFirstByOrderByRoomIdDesc();
	public Rooms findByRoomId(int id);
	
	@Transactional
	@Query("update Rooms r set r.available = :avail where r.roomId = :id")
	public int updateRoomAvailability(@Param("id") int id, @Param("avail") boolean avail);
	
	@Transactional
	@Query("update Rooms r set r.price = :price where r.roomId = :id")
	public int updateRoomPrice(@Param("id") int id, @Param("price") double price);
}
