package com.springpeople.resortmanagementsystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springpeople.resortmanagementsystem.entity.MemberStatus;
import com.springpeople.resortmanagementsystem.entity.Members;
import com.springpeople.resortmanagementsystem.exceptions.ResourceNotFoundException;
import com.springpeople.resortmanagementsystem.repository.MemberRepository;

@Service
public class MemberService {

	@Autowired
	private MemberRepository repo;
	
	public List<Members> listAllMembers() {
		return repo.findAll();
	}
	
	public Members retrieveDetailsById(int id) throws ResourceNotFoundException{
		Members m = repo.findByMemberId(id);
		
		if(m == null) {
			throw new ResourceNotFoundException("Member with id: " + id + " not found");
		}
		
		return m;
	}
	
	public Members retrieveDetailsByEmail(String email) throws ResourceNotFoundException {
		Members m =  repo.findByEmail(email);
		
		if(m == null) {
			throw new ResourceNotFoundException("Member with email: " + email + " not found");
		}
		
		return m;
	}
	
	public Members createMember(Members member) {
		Members m = repo.findFirstByOrderByMemberIdDesc();
		int id = 101;
		if (m != null) {
			id = m.getMemberId() + 1;
		}
		member.setMemberId(id);
		
		return repo.save(member);
	}
	
	public String updatePassword(int id, String pass) {
		String str = "Unable to update password. Try again later";
		
		int res = repo.updatePassword(id, pass);
		if(res > 0) {
			str = "Password updated successfully";
		}
		
		return str;
	}
	
	public String updatePhone(int id, String phone) {
		String str = "Unable to update phone number. Try again later";
		
		int res = repo.updatePhone(id, phone);
		if(res > 0) {
			str = "Phone number updated successfully";
		}
		
		return str;
	}
	
	public String updateWalletBalance(int id, double bal) {
		String str = "Unable to update wallet. Try again later";
		
		int res = repo.updateWalletBalance(id, bal);
		if(res > 0) {
			str = "Wallet Balance updated successfully";
		}
		
		return str;
	}
	
	public String updateStatus(int id, String status) {
		String str = "Unable to update status. Try again later";
		
		MemberStatus stat = MemberStatus.valueOf(status);
		
		int res = repo.updateStatus(id, stat);
		if(res > 0) {
			str = "Status updated successfully";
		}
		
		return str;
	}
	
	public List<Members> listAllMembersByStatus(int stat) {
		return repo.findAllByMemberStatus(stat);
	}
	
}
